<?php

return array(

	'search' => array(
		'case_insensitive' => true,
		'use_wildcards' => false,
	)

);
