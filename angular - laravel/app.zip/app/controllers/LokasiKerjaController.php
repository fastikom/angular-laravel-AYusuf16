<?php

class LokasiKerjaController extends \BaseController {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
//    protected $layout = 'backend.layouts.index';

    public function index() {
        //
        $data = array(
            'field' => LokasiKerja::getColumn(),
            'values' => LokasiKerja::orderBy('lokasi_kerja')->get()
        );
        return Response::json($data);
    }

    public function getLokasiKerja() {
        // data array yang menampung data berupa nama field tabel dan values dari tabel.
        $data = array(
            'field' => LokasiKerja::getColumn(),
            'values' => LokasiKerja::get()
        );
        return Response::json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store() {
        // membuat object baru dari LokasiKerja() dengan input lokasi_kerja
        $lokasi_kerja = new LokasiKerja();
        $lokasi_kerja->lokasi_kerja = Input::get('lokasi_kerja');
        // bila proses memasukan data berhasil maka akan mengirimkan response dalam bentuk json
        if ($lokasi_kerja->save()) {
            return Response::json(array('success' => TRUE));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {
        //
        $lokasi_kerja = LokasiKerja::find($id);
        return Response::json($lokasi_kerja);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id) {
        //
        $lokasi_kerja = LokasiKerja::find($id);
        $lokasi_kerja->lokasi_kerja = Input::get('lokasi_kerja');
        if ($lokasi_kerja->save()) {
            return Response::json(array('success' => TRUE));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        //
        $lokasi_kerja = LokasiKerja::find($id);
        if ($lokasi_kerja->delete()) {
            return Response::json(array('success' => TRUE));
        }
    }

}
