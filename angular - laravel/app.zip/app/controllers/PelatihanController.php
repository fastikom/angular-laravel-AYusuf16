<?php

class PelatihanController extends \BaseController {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index() {
        //
        $data = array(
            'field' => Pelatihan::getColumn(),
            'values' => Pelatihan::orderBy('nama_pelatihan')->get()
        );
        return Response::json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store() {
        //
        $pelatihan = new Pelatihan(Input::All());
        if ($pelatihan->save()) {
            return Response::json(array('success' => TRUE));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {
        //
        $pelatihan = Pelatihan::find($id);
        return Response::json($pelatihan);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id) {
        //
        $pelatihan = Pelatihan::find($id);
        if ($pelatihan->update(Input::All())) {
            return Response::json(array('success' => TRUE));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        //
        $pelatihan = Pelatihan::find($id);
        if ($pelatihan->delete()) {
            return Response::json(array('success' => TRUE));
        };
    }

}
